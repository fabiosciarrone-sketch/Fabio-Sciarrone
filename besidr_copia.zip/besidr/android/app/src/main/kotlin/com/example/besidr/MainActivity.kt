package com.example.besidr

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
