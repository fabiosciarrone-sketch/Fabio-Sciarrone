import 'package:flutter/material.dart';

class NotificationScreen extends StatelessWidget {
  const NotificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifiche'),
        backgroundColor: Colors.purple,
      ),
      body: const Center(
        child: Text(
          'Qui vedrai le tue notifiche',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
