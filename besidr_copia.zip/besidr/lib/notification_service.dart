import 'package:flutter/material.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'main.dart'; // Importato per usare la navigatorKey globale

class NotificationService {
  static final FirebaseMessaging _firebaseMessaging =
      FirebaseMessaging.instance;
  static final FlutterLocalNotificationsPlugin _localNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  // 1. Metodo di inizializzazione chiamato dal main.dart
  static Future<void> initialize() async {
    // Chiede i permessi all'utente
    NotificationSettings settings = await _firebaseMessaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('Permessi notifiche concessi!');
    }

    // Configurazione delle notifiche locali per Android
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);

    await _localNotificationsPlugin.initialize(initializationSettings);

    // Ricezione dei messaggi in primo piano con log di debug
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print(
          "🔥 onMessage INTERCETTATO! Titolo: ${message.notification?.title}");

      // Salva automaticamente la notifica su Firestore per alimentare la campanella e la schermata
      final user = FirebaseAuth.instance.currentUser;
      if (user != null && message.notification != null) {
        FirebaseFirestore.instance.collection('notifications').add({
          'userId': user.uid,
          'title': message.notification?.title ?? 'Nuova Notifica',
          'body': message.notification?.body ?? '',
          'isRead': false,
          'createdAt': FieldValue.serverTimestamp(),
        });
      }

      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;

      // Gestione notifica locale per Android
      if (notification != null && android != null) {
        _localNotificationsPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          const NotificationDetails(
            android: AndroidNotificationDetails(
              'sidebyside_chat_channel',
              'Notifiche Chat',
              channelDescription: 'Canale per le notifiche dei messaggi',
              importance: Importance.max,
              priority: Priority.high,
            ),
          ),
        );
      }

      // Mostra il popup grafico all'interno dell'app quando è aperta in primo piano
      if (notification != null) {
        print("📱 Controllando il navigatorKey context...");
        if (navigatorKey.currentContext != null) {
          print("🟢 CONTESTO TROVATO: Apro il popup a schermo!");
          showDialog(
            context: navigatorKey.currentContext!,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text(notification.title ?? 'Nuova Notifica'),
                content: Text(notification.body ?? ''),
                actions: [
                  TextButton(
                    child: const Text('OK'),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              );
            },
          );
        } else {
          print("🔴 ATTENZIONE: navigatorKey.currentContext è NULL!");
        }
      }
    });

    // Gestione del click sulla notifica quando l'app è in background
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print(
          "🚀 onMessageOpenedApp INTERCETTATO! Titolo: ${message.notification?.title}");
    });

    // Gestione del click quando l'app era completamente chiusa (Terminated)
    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage? message) {
      if (message != null) {
        print(
            "🚀 App aperta da stato Terminated tramite notifica! Titolo: ${message.notification?.title}");
      }
    });

    // Ascolta se il token cambia e lo aggiorna automaticamente
    _firebaseMessaging.onTokenRefresh.listen((token) {
      saveTokenToDatabase(token); // Nome corretto del metodo
    });
  }

  // 2. Metodo per salvare il token associato all'utente su Firestore (chiamato da auth_screen.dart)
  static Future<void> saveTokenToDatabase(String token) async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .update({
        'fcmToken': token,
      }).catchError((e) {
        // Se il documento non esiste ancora, lo crea o lo aggiorna in merge
        FirebaseFirestore.instance.collection('users').doc(user.uid).set({
          'fcmToken': token,
        }, SetOptions(merge: true));
      });
    }
  }
}
