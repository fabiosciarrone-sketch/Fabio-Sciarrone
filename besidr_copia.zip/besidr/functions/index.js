const { onRequest } = require("firebase-functions/v2/https");
const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.getPlaces = onRequest(async (req, res) => {
  // Abilita i CORS per permettere l'accesso dal tuo sito web
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.set("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.status(204).send("");
    return;
  }

  const { lat, lng, type } = req.query;
  const apiKey = "AIzaSyBaO9OavQjO2E6YclqHusfFDlTK9VKJK2E"; // Inserisci qui la tua chiave API di Google Maps

  const googleUrl = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${lat},${lng}&radius=2000&type=${type || 'gym|bar|store|restaurant'}&key=${apiKey}`;

  try {
    const response = await fetch(googleUrl);
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
});

// Cloud Function per l'invio delle notifiche push per Like e Super Like
exports.sendPushNotificationOnLike = functions.firestore
  .document('likes/{likeId}')
  .onCreate(async (snapshot, context) => {
    const likeData = snapshot.data();
    const receiverId = likeData.toUserId;
    const senderId = likeData.fromUserId;
    const type = likeData.type; // 'like' o 'super_like'

    // 1. Recupera il token FCM del destinatario dalla collezione 'users'
    const receiverDoc = await admin.firestore().collection('users').doc(receiverId).get();
    if (!receiverDoc.exists) return null;
    
    const fcmToken = receiverDoc.data().fcmToken;
    if (!fcmToken) return null; // Se l'utente non ha un token, usciamo

    // 2. Recupera il nome del mittente per rendere la notifica carina
    const senderDoc = await admin.firestore().collection('users').doc(senderId).get();
    const senderName = senderDoc.exists ? (senderDoc.data().firstName || 'Un utente') : 'Un utente';

    // 3. Prepara il testo in base al tipo (Like o Super Like)
    const title = type === 'super_like' ? '💎 Nuovo Super Like!' : '❤️ Nuovo Cuoricino!';
    const body = type === 'super_like' 
      ? `${senderName} ti ha mandato un Super Like!` 
      : `${senderName} ha messo un like al tuo profilo!`;

    // 4. Costruisci il payload della notifica
    const message = {
      token: fcmToken,
      notification: {
        title: title,
        body: body,
      },
      data: {
        click_action: 'FLUTTER_NOTIFICATION_CLICK',
        senderId: senderId,
      }
    };

    // 5. Invia la notifica tramite Firebase Cloud Messaging
    try {
      await admin.messaging().send(message);
      console.log('Notifica push inviata con successo!');
    } catch (error) {
      console.error('Errore durante l\'invio della notifica push:', error);
    }
  });
